package psa.naloga5;

import java.util.Arrays;

public class Prim {
	int[][] data;
	int n;

	public Prim(int n) {
		data = new int[n][n];
		this.n = n;
	}

	public Prim(int[][] d) {
		data=d;
		n=d.length;
	}

	public void addEdge(int i, int j, int d) {
		data[i][j]=d;
		data[j][i]=d;
	}

	public int MSTcost() {
		int suma=0;
		int s=0;
		Integer min_val=Integer.MIN_VALUE;
		Integer max_val=Integer.MAX_VALUE;
		int[] parent=new int[n];
		Integer[] distance=new Integer[n];
		boolean[] visited=new boolean[n];
		for (int i = 0; i < n; i++) {visited[i]=false;distance[i]=max_val;}
		
		visited[s]=true;
		distance[s]=0;
		parent[s]=s;
		
		
		for (int i = 0; i < n; i++) {
			int id=s;
			for (int j = 0; j < n; j++) {
				if(data[s][j]!=0 && !visited[j]) {
					if(distance[j]>data[s][j]) {distance[j]=data[s][j];parent[j]=s;}
				}
			}
			Integer min=max_val;
			for (int j = 0; j < n; j++) {
				if(!visited[j]  && min>distance[j] && distance[j]!=0) {id=j;min=distance[j];/*Tu dodamo za sabiranje!*/}
			}
			
			visited[id]=true;
			suma+=distance[id];
			distance[id]=0;
			s=id;
		}
		

		return suma;
	}
	
	public int[] prim(int s) {
		Integer min_val=Integer.MIN_VALUE;
		Integer max_val=Integer.MAX_VALUE;
		int[] parent=new int[n];
		Integer[] distance=new Integer[n];
		boolean[] visited=new boolean[n];
		for (int i = 0; i < n; i++) {visited[i]=false;distance[i]=max_val;}
		
		visited[s]=true;
		distance[s]=0;
		parent[s]=0;
		
		
		for (int i = 0; i < n; i++) {
			int id=s;
			for (int j = 0; j < n; j++) {
				if(data[s][j]!=0 && !visited[j]) {
					if(distance[j]>data[s][j]) {distance[j]=data[s][j];parent[j]=s;}
				}
			}
			Integer min=max_val;
			for (int j = 0; j < n; j++) {
				if(!visited[j]  && min>distance[j] && distance[j]!=0) {id=j;min=distance[j];/*Tu dodamo za sabiranje!*/}
			}
			
			visited[id]=true;
			distance[id]=0;
			s=id;
		}
		return parent;
	}

	/*public static void main(String[] args) {
		int[][] data= {{0,2,3,0,0,0},{2,0,6,5,3,0},{3,6,0,0,2,0},{0,5,0,0,1,2},{0,3,2,1,0,4},{0,0,0,2,4,0}};
		Prim p=new Prim(data);
		int[] t=p.prim(0);
		for (int i = 0; i < t.length; i++) {
			System.out.print(t[i]+" ");
		}
		System.out.println();
		System.out.println(p.MSTcost());
	}*/
}
